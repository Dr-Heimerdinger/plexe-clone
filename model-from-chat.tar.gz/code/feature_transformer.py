
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from plexe.core.interfaces.feature_transformer import FeatureTransformer

class FeatureTransformerImplementation(FeatureTransformer):
    def __init__(self):
        # Define ordinal mappings
        self.ordinal_mapping = {
            'ExterQual': {'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'ExterCond': {'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'HeatingQC': {'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'KitchenQual': {'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'BsmtQual': {'None': 0, 'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'BsmtCond': {'None': 0, 'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'FireplaceQu': {'None': 0, 'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'GarageQual': {'None': 0, 'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'GarageCond': {'None': 0, 'Po': 1, 'Fa': 2, 'TA': 3, 'Gd': 4, 'Ex': 5},
            'BsmtExposure': {'None': 0, 'No': 1, 'Mn': 2, 'Av': 3, 'Gd': 4},
            'BsmtFinType1': {'None': 0, 'Unf': 1, 'LwQ': 2, 'Rec': 3, 'BLQ': 4, 'ALQ': 5, 'GLQ': 6},
            'BsmtFinType2': {'None': 0, 'Unf': 1, 'LwQ': 2, 'Rec': 3, 'BLQ': 4, 'ALQ': 5, 'GLQ': 6},
            'Functional': {'Sal': 1, 'Sev': 2, 'Maj2': 3, 'Maj1': 4, 'Mod': 5, 'Min2': 6, 'Min1': 7, 'Typ': 8},
            'PavedDrive': {'N': 0, 'P': 1, 'Y': 2},
            'LotShape': {'IR3': 0, 'IR2': 1, 'IR1': 2, 'Reg': 3},
            'LandContour': {'Low': 0, 'Bnk': 1, 'HLS': 2, 'Lvl': 3}
        }
        self.numerical_cols_log_transform = [
            'LotFrontage', 'LotArea', 'MasVnrArea', 'BsmtFinSF1', 'BsmtFinSF2',
            'BsmtUnfSF', 'TotalBsmtSF', '1stFlrSF', '2ndFlrSF', 'GrLivArea',
            'WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', 'ScreenPorch'
        ]
        
        self.numerical_features = None
        self.nominal_cols = None
        self.preprocessor = None

    def transform(self, inputs: pd.DataFrame) -> pd.DataFrame:
        df = inputs.copy()

        # Store SalePrice aside temporarily and apply log1p transformation
        sale_price_transformed = np.log1p(df['SalePrice'])
        df = df.drop(columns=['SalePrice'])

        # 2. Missing Value Imputation
        for col in ['FireplaceQu', 'GarageType', 'GarageFinish', 'GarageQual', 'GarageCond',
                     'BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2']:
            df[col] = df[col].fillna('None')

        df['MasVnrArea'] = df['MasVnrArea'].fillna(0)
        df['LotFrontage'] = df['LotFrontage'].fillna(df['LotFrontage'].median())
        df['GarageYrBlt'] = df['GarageYrBlt'].fillna(df['YearBuilt'])

        # 3. New Feature Creation
        df['TotalSF'] = df['TotalBsmtSF'] + df['1stFlrSF'] + df['2ndFlrSF']
        df['TotalBath'] = df['FullBath'] + df['HalfBath'] * 0.5 + df['BsmtFullBath'] + df['BsmtHalfBath'] * 0.5
        df['OverallQual_GrLivArea'] = df['OverallQual'] * df['GrLivArea']
        df['Age'] = df['YrSold'] - df['YearBuilt']
        df['RemodelAge'] = df['YrSold'] - df['YearRemodAdd']
        df['GarageAge'] = df['YrSold'] - df['GarageYrBlt']
        df['GarageAge'] = df['GarageAge'].apply(lambda x: x if x >= 0 else 0)

        # Convert MSSubClass to object type before encoding
        df['MSSubClass'] = df['MSSubClass'].astype(str)

        # Apply ordinal encoding
        for col, mapping in self.ordinal_mapping.items():
            if col in df.columns:
                df[col] = df[col].map(mapping).fillna(0) 

        # Apply log1p transformation to skewed numerical features
        for col in self.numerical_cols_log_transform:
            if col in df.columns:
                df[col] = np.log1p(df[col] + 1)

        # Identify numerical and nominal columns for scaling/one-hot encoding
        self.numerical_features = df.select_dtypes(include=np.number).columns.tolist()
        self.nominal_cols = df.select_dtypes(include='object').columns.tolist() 

        # Set up preprocessing pipeline (fit only if not already fitted)
        if self.preprocessor is None:
            numerical_transformer = Pipeline(steps=[
                ('scaler', StandardScaler())
            ])

            categorical_transformer = Pipeline(steps=[
                ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
            ])

            self.preprocessor = ColumnTransformer(
                transformers=[
                    ('num', numerical_transformer, self.numerical_features),
                    ('cat', categorical_transformer, self.nominal_cols)
                ],
                remainder='drop' 
            )
            self.preprocessor.fit(df)
        
        # Apply transformations
        transformed_array = self.preprocessor.transform(df)
        
        # Get all feature names out from the preprocessor
        transformed_feature_names = self.preprocessor.get_feature_names_out()
        
        # Create new DataFrame
        transformed_df = pd.DataFrame(transformed_array, columns=transformed_feature_names, index=inputs.index)

        # Re-attach the log-transformed SalePrice
        transformed_df['SalePrice'] = sale_price_transformed

        return transformed_df

