
import pandas as pd
from sklearn.metrics import mean_squared_error
import numpy as np

from plexe.core.object_registry import ObjectRegistry
from plexe.internal.common.datasets.interface import TabularConvertible
from plexe.core.interfaces.predictor import Predictor

SOLUTION_ID = '0b4b606782234d3cafef7dc2fe66ddef'
TARGET_METRIC_NAME = 'Root Mean Squared Error'
EXPECTED_INPUT_SCHEMA = {'num__LotFrontage': 'float', 'num__LotArea': 'float', 'num__LotShape': 'float', 'num__LandContour': 'float', 'num__OverallQual': 'float', 'num__OverallCond': 'float', 'num__YearBuilt': 'float', 'num__YearRemodAdd': 'float', 'num__MasVnrArea': 'float', 'num__ExterQual': 'float', 'num__ExterCond': 'float', 'num__BsmtQual': 'float', 'num__BsmtCond': 'float', 'num__BsmtExposure': 'float', 'num__BsmtFinType1': 'float', 'num__BsmtFinSF1': 'float', 'num__BsmtFinType2': 'float', 'num__BsmtFinSF2': 'float', 'num__BsmtUnfSF': 'float', 'num__TotalBsmtSF': 'float', 'num__HeatingQC': 'float', 'num__1stFlrSF': 'float', 'num__2ndFlrSF': 'float', 'num__GrLivArea': 'float', 'num__BsmtFullBath': 'float', 'num__BsmtHalfBath': 'float', 'num__FullBath': 'float', 'num__HalfBath': 'float', 'num__BedroomAbvGr': 'float', 'num__KitchenQual': 'float', 'num__TotRmsAbvGrd': 'float', 'num__Functional': 'float', 'num__Fireplaces': 'float', 'num__FireplaceQu': 'float', 'num__GarageYrBlt': 'float', 'num__GarageCars': 'float', 'num__GarageArea': 'float', 'num__GarageQual': 'float', 'num__GarageCond': 'float', 'num__PavedDrive': 'float', 'num__WoodDeckSF': 'float', 'num__OpenPorchSF': 'float', 'num__EnclosedPorch': 'float', 'num__ScreenPorch': 'float', 'num__MoSold': 'float', 'num__YrSold': 'float', 'num__TotalSF': 'float', 'num__TotalBath': 'float', 'num__OverallQual_GrLivArea': 'float', 'num__Age': 'float', 'num__RemodelAge': 'float', 'num__GarageAge': 'float', 'cat__MSSubClass_120': 'float', 'cat__MSSubClass_160': 'float', 'cat__MSSubClass_180': 'float', 'cat__MSSubClass_190': 'float', 'cat__MSSubClass_20': 'float', 'cat__MSSubClass_30': 'float', 'cat__MSSubClass_40': 'float', 'cat__MSSubClass_45': 'float', 'cat__MSSubClass_50': 'float', 'cat__MSSubClass_60': 'float', 'cat__MSSubClass_70': 'float', 'cat__MSSubClass_75': 'float', 'cat__MSSubClass_80': 'float', 'cat__MSSubClass_85': 'float', 'cat__MSSubClass_90': 'float', 'cat__MSZoning_C (all)': 'float', 'cat__MSZoning_FV': 'float', 'cat__MSZoning_RH': 'float', 'cat__MSZoning_RL': 'float', 'cat__MSZoning_RM': 'float', 'cat__LotConfig_Corner': 'float', 'cat__LotConfig_CulDSac': 'float', 'cat__LotConfig_FR2': 'float', 'cat__LotConfig_FR3': 'float', 'cat__LotConfig_Inside': 'float', 'cat__Neighborhood_Blmngtn': 'float', 'cat__Neighborhood_BrDale': 'float', 'cat__Neighborhood_BrkSide': 'float', 'cat__Neighborhood_ClearCr': 'float', 'cat__Neighborhood_CollgCr': 'float', 'cat__Neighborhood_Crawfor': 'float', 'cat__Neighborhood_Edwards': 'float', 'cat__Neighborhood_Gilbert': 'float', 'cat__Neighborhood_IDOTRR': 'float', 'cat__Neighborhood_MeadowV': 'float', 'cat__Neighborhood_Mitchel': 'float', 'cat__Neighborhood_NAmes': 'float', 'cat__Neighborhood_NPkVill': 'float', 'cat__Neighborhood_NWAmes': 'float', 'cat__Neighborhood_NoRidge': 'float', 'cat__Neighborhood_NridgHt': 'float', 'cat__Neighborhood_OldTown': 'float', 'cat__Neighborhood_SWISU': 'float', 'cat__Neighborhood_Sawyer': 'float', 'cat__Neighborhood_SawyerW': 'float', 'cat__Neighborhood_Somerst': 'float', 'cat__Neighborhood_StoneBr': 'float', 'cat__Neighborhood_Timber': 'float', 'cat__Neighborhood_Veenker': 'float', 'cat__Condition1_Artery': 'float', 'cat__Condition1_Feedr': 'float', 'cat__Condition1_Norm': 'float', 'cat__Condition1_PosA': 'float', 'cat__Condition1_PosN': 'float', 'cat__Condition1_RRAe': 'float', 'cat__Condition1_RRAn': 'float', 'cat__Condition1_RRNe': 'float', 'cat__Condition1_RRNn': 'float', 'cat__BldgType_1Fam': 'float', 'cat__BldgType_2fmCon': 'float', 'cat__BldgType_Duplex': 'float', 'cat__BldgType_Twnhs': 'float', 'cat__BldgType_TwnhsE': 'float', 'cat__HouseStyle_1.5Fin': 'float', 'cat__HouseStyle_1.5Unf': 'float', 'cat__HouseStyle_1Story': 'float', 'cat__HouseStyle_2.5Fin': 'float', 'cat__HouseStyle_2.5Unf': 'float', 'cat__HouseStyle_2Story': 'float', 'cat__HouseStyle_SFoyer': 'float', 'cat__HouseStyle_SLvl': 'float', 'cat__RoofStyle_Flat': 'float', 'cat__RoofStyle_Gable': 'float', 'cat__RoofStyle_Gambrel': 'float', 'cat__RoofStyle_Hip': 'float', 'cat__RoofStyle_Mansard': 'float', 'cat__Exterior1st_AsbShng': 'float', 'cat__Exterior1st_BrkComm': 'float', 'cat__Exterior1st_BrkFace': 'float', 'cat__Exterior1st_CemntBd': 'float', 'cat__Exterior1st_HdBoard': 'float', 'cat__Exterior1st_MetalSd': 'float', 'cat__Exterior1st_Plywood': 'float', 'cat__Exterior1st_Stucco': 'float', 'cat__Exterior1st_VinylSd': 'float', 'cat__Exterior1st_Wd Sdng': 'float', 'cat__Exterior1st_WdShing': 'float', 'cat__Exterior2nd_AsbShng': 'float', 'cat__Exterior2nd_AsphShn': 'float', 'cat__Exterior2nd_Brk Cmn': 'float', 'cat__Exterior2nd_BrkFace': 'float', 'cat__Exterior2nd_CmentBd': 'float', 'cat__Exterior2nd_HdBoard': 'float', 'cat__Exterior2nd_ImStucc': 'float', 'cat__Exterior2nd_MetalSd': 'float', 'cat__Exterior2nd_Plywood': 'float', 'cat__Exterior2nd_Stucco': 'float', 'cat__Exterior2nd_VinylSd': 'float', 'cat__Exterior2nd_Wd Sdng': 'float', 'cat__Exterior2nd_Wd Shng': 'float', 'cat__Foundation_BrkTil': 'float', 'cat__Foundation_CBlock': 'float', 'cat__Foundation_PConc': 'float', 'cat__Foundation_Slab': 'float', 'cat__Foundation_Stone': 'float', 'cat__Foundation_Wood': 'float', 'cat__CentralAir_N': 'float', 'cat__CentralAir_Y': 'float', 'cat__Electrical_FuseA': 'float', 'cat__Electrical_FuseF': 'float', 'cat__Electrical_FuseP': 'float', 'cat__Electrical_Mix': 'float', 'cat__Electrical_SBrkr': 'float', 'cat__GarageType_2Types': 'float', 'cat__GarageType_Attchd': 'float', 'cat__GarageType_Basment': 'float', 'cat__GarageType_BuiltIn': 'float', 'cat__GarageType_CarPort': 'float', 'cat__GarageType_Detchd': 'float', 'cat__GarageType_None': 'float', 'cat__GarageFinish_Fin': 'float', 'cat__GarageFinish_None': 'float', 'cat__GarageFinish_RFn': 'float', 'cat__GarageFinish_Unf': 'float', 'cat__SaleType_COD': 'float', 'cat__SaleType_CWD': 'float', 'cat__SaleType_Con': 'float', 'cat__SaleType_ConLD': 'float', 'cat__SaleType_ConLI': 'float', 'cat__SaleType_ConLw': 'float', 'cat__SaleType_New': 'float', 'cat__SaleType_WD': 'float', 'cat__SaleCondition_Abnorml': 'float', 'cat__SaleCondition_AdjLand': 'float', 'cat__SaleCondition_Alloca': 'float', 'cat__SaleCondition_Family': 'float', 'cat__SaleCondition_Normal': 'float', 'cat__SaleCondition_Partial': 'float'}

# Get test dataset name
test_dataset_name = "dataset_0_transformed_test" # This is fixed for the task
# Get objects from registry
object_registry = ObjectRegistry()

# Get test dataset
test_dataset_obj = object_registry.get(TabularConvertible, test_dataset_name)
test_df = test_dataset_obj.to_pandas()  # Convert to pandas DataFrame

# Get the instantiated predictor
predictor = object_registry.get(Predictor, "trained_predictor")

# Separate features (X) and target (y)
X_test = test_df.drop(columns=['SalePrice'])
y_test = test_df['SalePrice']

# Ensure X_test columns match input schema (handle potential missing columns by adding with default 0.0)
expected_input_cols = list(EXPECTED_INPUT_SCHEMA.keys())
missing_cols = set(expected_input_cols) - set(X_test.columns)
if missing_cols:
    for col in missing_cols:
        X_test[col] = 0.0 # Add missing columns with a default value (e.g., 0.0 for float)
# Reorder columns to match the expected input schema
X_test = X_test[expected_input_cols]

# Make predictions
X_test_dict_list = X_test.to_dict(orient='records')
predictions_raw = predictor.predict(X_test_dict_list)
y_pred = np.array([p['SalePrice'] for p in predictions_raw])
y_test_array = y_test.values

# Compute performance metrics (RMSE)
rmse = np.sqrt(mean_squared_error(y_test_array, y_pred))

# Performance Summary
model_performance_summary = {
    TARGET_METRIC_NAME: rmse,
    'Mean Absolute Error': np.mean(np.abs(y_pred - y_test_array)),
    'Max Absolute Error': np.max(np.abs(y_pred - y_test_array))
}
print(f"Model Performance Summary: {model_performance_summary}")
