
import pandas as pd
from sklearn.model_selection import train_test_split

# Assuming 'df' is the loaded pandas DataFrame
df_sorted = df.sort_values(by=['num__YrSold', 'num__MoSold']).reset_index(drop=True)

train_ratio = 0.7
val_ratio = 0.15
test_ratio = 0.15

total_size = len(df_sorted)
train_size = int(total_size * train_ratio)
val_size = int(total_size * val_ratio)
test_size = total_size - train_size - val_size

train_df = df_sorted.iloc[:train_size]
val_df = df_sorted.iloc[train_size : train_size + val_size]
test_df = df_sorted.iloc[train_size + val_size :]
