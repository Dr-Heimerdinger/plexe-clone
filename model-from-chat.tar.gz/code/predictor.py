
import pandas as pd
import numpy as np
import joblib
import xgboost as xgb # Required for XGBoost model, even if just loading
from typing import List, Dict, Union

from plexe.internal.models.entities.artifact import Artifact
from plexe.core.interfaces.predictor import Predictor


class PredictorImplementation(Predictor):
    def __init__(self, artifacts: List[Artifact]):
        """
        Instantiates the predictor using the provided model artifacts.
        :param artifacts: list of BinaryIO artifacts
        """
        artifact = self._get_artifact("xgboost_regressor_model.joblib", artifacts)
        with artifact.get_as_handle() as binary_io:
            self.model = joblib.load(binary_io)

        # Define the expected feature order based on input_schema
        # The order of features from the input_schema matches the order X_train was passed to model.fit
        self.feature_names = [
            'num__LotFrontage', 'num__LotArea', 'num__LotShape', 'num__LandContour', 'num__OverallQual', 'num__OverallCond', 'num__YearBuilt', 'num__YearRemodAdd', 'num__MasVnrArea', 'num__ExterQual', 'num__ExterCond', 'num__BsmtQual', 'num__BsmtCond', 'num__BsmtExposure', 'num__BsmtFinType1', 'num__BsmtFinSF1', 'num__BsmtFinType2', 'num__BsmtFinSF2', 'num__BsmtUnfSF', 'num__TotalBsmtSF', 'num__HeatingQC', 'num__1stFlrSF', 'num__2ndFlrSF', 'num__GrLivArea', 'num__BsmtFullBath', 'num__BsmtHalfBath', 'num__FullBath', 'num__HalfBath', 'num__BedroomAbvGr', 'num__KitchenQual', 'num__TotRmsAbvGrd', 'num__Functional', 'num__Fireplaces', 'num__FireplaceQu', 'num__GarageYrBlt', 'num__GarageCars', 'num__GarageArea', 'num__GarageQual', 'num__GarageCond', 'num__PavedDrive', 'num__WoodDeckSF', 'num__OpenPorchSF', 'num__EnclosedPorch', 'num__ScreenPorch', 'num__MoSold', 'num__YrSold', 'num__TotalSF', 'num__TotalBath', 'num__OverallQual_GrLivArea', 'num__Age', 'num__RemodelAge', 'num__GarageAge', 'cat__MSSubClass_120', 'cat__MSSubClass_160', 'cat__MSSubClass_180', 'cat__MSSubClass_190', 'cat__MSSubClass_20', 'cat__MSSubClass_30', 'cat__MSSubClass_40', 'cat__MSSubClass_45', 'cat__MSSubClass_50', 'cat__MSSubClass_60', 'cat__MSSubClass_70', 'cat__MSSubClass_75', 'cat__MSSubClass_80', 'cat__MSSubClass_85', 'cat__MSSubClass_90', 'cat__MSZoning_C (all)', 'cat__MSZoning_FV', 'cat__MSZoning_RH', 'cat__MSZoning_RL', 'cat__MSZoning_RM', 'cat__LotConfig_Corner', 'cat__LotConfig_CulDSac', 'cat__LotConfig_FR2', 'cat__LotConfig_FR3', 'cat__LotConfig_Inside', 'cat__Neighborhood_Blmngtn', 'cat__Neighborhood_BrDale', 'cat__Neighborhood_BrkSide', 'cat__Neighborhood_ClearCr', 'cat__Neighborhood_CollgCr', 'cat__Neighborhood_Crawfor', 'cat__Neighborhood_Edwards', 'cat__Neighborhood_Gilbert', 'cat__Neighborhood_IDOTRR', 'cat__Neighborhood_MeadowV', 'cat__Neighborhood_Mitchel', 'cat__Neighborhood_NAmes', 'cat__Neighborhood_NPkVill', 'cat__Neighborhood_NWAmes', 'cat__Neighborhood_NoRidge', 'cat__Neighborhood_NridgHt', 'cat__Neighborhood_OldTown', 'cat__Neighborhood_SWISU', 'cat__Neighborhood_Sawyer', 'cat__Neighborhood_SawyerW', 'cat__Neighborhood_Somerst', 'cat__Neighborhood_StoneBr', 'cat__Neighborhood_Timber', 'cat__Neighborhood_Veenker', 'cat__Condition1_Artery', 'cat__Condition1_Feedr', 'cat__Condition1_Norm', 'cat__Condition1_PosA', 'cat__Condition1_PosN', 'cat__Condition1_RRAe', 'cat__Condition1_RRAn', 'cat__Condition1_RRNe', 'cat__Condition1_RRNn', 'cat__BldgType_1Fam', 'cat__BldgType_2fmCon', 'cat__BldgType_Duplex', 'cat__BldgType_Twnhs', 'cat__BldgType_TwnhsE', 'cat__HouseStyle_1.5Fin', 'cat__HouseStyle_1.5Unf', 'cat__HouseStyle_1Story', 'cat__HouseStyle_2.5Fin', 'cat__HouseStyle_2.5Unf', 'cat__HouseStyle_2Story', 'cat__HouseStyle_SFoyer', 'cat__HouseStyle_SLvl', 'cat__RoofStyle_Flat', 'cat__RoofStyle_Gable', 'cat__RoofStyle_Gambrel', 'cat__RoofStyle_Hip', 'cat__RoofStyle_Mansard', 'cat__Exterior1st_AsbShng', 'cat__Exterior1st_BrkComm', 'cat__Exterior1st_BrkFace', 'cat__Exterior1st_CemntBd', 'cat__Exterior1st_HdBoard', 'cat__Exterior1st_MetalSd', 'cat__Exterior1st_Plywood', 'cat__Exterior1st_Stucco', 'cat__Exterior1st_VinylSd', 'cat__Exterior1st_Wd Sdng', 'cat__Exterior1st_WdShing', 'cat__Exterior2nd_AsbShng', 'cat__Exterior2nd_AsphShn', 'cat__Exterior2nd_Brk Cmn', 'cat__Exterior2nd_BrkFace', 'cat__Exterior2nd_CmentBd', 'cat__Exterior2nd_HdBoard', 'cat__Exterior2nd_ImStucc', 'cat__Exterior2nd_MetalSd', 'cat__Exterior2nd_Plywood', 'cat__Exterior2nd_Stucco', 'cat__Exterior2nd_VinylSd', 'cat__Exterior2nd_Wd Sdng', 'cat__Exterior2nd_Wd Shng', 'cat__Foundation_BrkTil', 'cat__Foundation_CBlock', 'cat__Foundation_PConc', 'cat__Foundation_Slab', 'cat__Foundation_Stone', 'cat__Foundation_Wood', 'cat__CentralAir_N', 'cat__CentralAir_Y', 'cat__Electrical_FuseA', 'cat__Electrical_FuseF', 'cat__Electrical_FuseP', 'cat__Electrical_Mix', 'cat__Electrical_SBrkr', 'cat__GarageType_2Types', 'cat__GarageType_Attchd', 'cat__GarageType_Basment', 'cat__GarageType_BuiltIn', 'cat__GarageType_CarPort', 'cat__GarageType_Detchd', 'cat__GarageType_None', 'cat__GarageFinish_Fin', 'cat__GarageFinish_None', 'cat__GarageFinish_RFn', 'cat__GarageFinish_Unf', 'cat__SaleType_COD', 'cat__SaleType_CWD', 'cat__SaleType_Con', 'cat__SaleType_ConLD', 'cat__SaleType_ConLI', 'cat__SaleType_ConLw', 'cat__SaleType_New', 'cat__SaleType_WD', 'cat__SaleCondition_Abnorml', 'cat__SaleCondition_AdjLand', 'cat__SaleCondition_Alloca', 'cat__SaleCondition_Family', 'cat__SaleCondition_Normal', 'cat__SaleCondition_Partial'
        ]


    def predict(self, inputs: Union[Dict, List[Dict]]) -> Union[Dict, List[Dict]]:
        """
        Given an input conforming to the input schema, return the model's prediction
        as a dict conforming to the output schema.
        """
        preprocessed_input = self._preprocess_input(inputs)
        predictions_log1p = self.model.predict(preprocessed_input)
        return self._postprocess_output(predictions_log1p)

    def _preprocess_input(self, inputs: Union[Dict, List[Dict]]):
        """Map the input data from a dict or list of dicts to the input format of the underlying model."""
        if isinstance(inputs, dict):
            inputs = [inputs]  # Wrap single dict in a list for consistent DataFrame creation

        # Create DataFrame from input dictionaries, ensuring correct column order
        # Use reindex to make sure all expected columns are present, and in the correct order.
        # Fill missing columns with 0.0 as per typical one-hot encoding behavior for unseen categories,
        # or other appropriate default for numerical features if not present.
        # This assumes that the training data handling of missing values (if any)
        # aligns with filling NaNs from reindex with 0.0.
        input_df = pd.DataFrame(inputs).reindex(columns=self.feature_names, fill_value=0.0)

        # Ensure all columns are float as per schema
        for col in input_df.columns:
            if input_df[col].dtype != 'float64': # XGBoost expects float features
                input_df[col] = input_df[col].astype('float64')

        return input_df

    def _postprocess_output(self, outputs: np.ndarray) -> Union[Dict, List[Dict]]:
        """Map the output from the underlying model to a dict or list of dicts compliant with the output schema."""
        # Apply numpy.expm1 to reverse the log1p transformation
        predictions_original_scale = np.expm1(outputs)

        # Format as a list of dictionaries if multiple predictions, or a single dictionary if one.
        if len(predictions_original_scale) == 1:
            return {'SalePrice': float(predictions_original_scale[0])}
        else:
            return [{'SalePrice': float(p)} for p in predictions_original_scale]

    @staticmethod
    def _get_artifact(name: str, artifacts: List[Artifact]) -> Artifact:
        """Given the name of a binary artifact, return the corresponding artifact from the list."""
        # Do not modify this method.
        for artifact in artifacts:
            if artifact.name == name:
                return artifact
        raise ValueError(f"Artifact {name} not found in the provided artifacts.")
