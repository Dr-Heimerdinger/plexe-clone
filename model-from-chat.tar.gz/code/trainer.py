import pandas as pd
import numpy as np
import xgboost as xgb
import joblib
from sklearn.metrics import mean_squared_error

# Define file paths for training and validation data
TRAIN_DATA_FILE = "dataset_0_transformed_train.parquet"
VAL_DATA_FILE = "dataset_0_transformed_val.parquet"

# Define the name of the target column
TARGET_COLUMN = "SalePrice"

# Define the filename for saving the trained model
MODEL_FILENAME = "xgboost_regressor_model.joblib"

# --- 1. Load Data ---
# Load the preprocessed training dataset.
# It is assumed that 'SalePrice' (the target) has been log1p-transformed
# and features have been appropriately scaled and encoded.
train_df = pd.read_parquet(TRAIN_DATA_FILE)

# Separate features (X) and target (y) for the training set.
X_train = train_df.drop(columns=[TARGET_COLUMN])
y_train = train_df[TARGET_COLUMN]

# Load the preprocessed validation dataset.
val_df = pd.read_parquet(VAL_DATA_FILE)

# Separate features (X) and target (y) for the validation set.
X_val = val_df.drop(columns=[TARGET_COLUMN])
y_val = val_df[TARGET_COLUMN]

# --- 2. Initialize and Train XGBoost Regressor ---
# Initialize the XGBoost Regressor model.
# Using default hyperparameters as specified in the plan.
# 'objective': 'reg:squarederror' is standard for regression tasks and suppresses a common warning.
# 'n_jobs': -1 utilizes all available CPU cores for faster training.
# 'random_state': 42 ensures reproducibility of the training process.
model = xgb.XGBRegressor(objective="reg:squarederror", n_jobs=-1, random_state=42)

# Train the model using only the training data.
# The model learns the mapping from features to the log1p-transformed 'SalePrice'.
model.fit(X_train, y_train)

# --- 3. Predict and Inverse Transform ---
# Make predictions on the validation dataset.
# These predictions are in the log1p-transformed scale.
predictions_log1p = model.predict(X_val)

# Apply numpy.expm1 to the predictions to reverse the log1p transformation.
# This brings the predicted house prices back to their original dollar scale.
predictions_original_scale = np.expm1(predictions_log1p)

# Also inverse transform the actual validation target (y_val) to its original scale.
# This is necessary to compute RMSE on the true, untransformed house prices.
actual_original_scale = np.expm1(y_val)

# --- 4. Evaluate Model Performance ---
# Calculate the Root Mean Squared Error (RMSE) between the
# inverse-transformed predictions and the actual original sale prices.
# RMSE is a standard metric for regression tasks and is calculated on the original scale
# as specified in the plan.
rmse = np.sqrt(mean_squared_error(actual_original_scale, predictions_original_scale))

# Print the RMSE metric to standard output in the specified format.
print(f"RMSE: {rmse}")

# --- 5. Save Model ---
# Save the trained XGBoost Regressor model to the current directory.
# 'joblib' is used for efficient serialization of scikit-learn compatible models.
joblib.dump(model, MODEL_FILENAME)
